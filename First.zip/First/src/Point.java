public class Point {
    public double x;
    public double y;

    public String toString() {
        return "P(x,y)=(" + x + "," + y + ")";
    }
}
