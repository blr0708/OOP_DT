public class Main {
    public static void main(String[] args) {
        Point p = new Point();
        p.x = 3;
        p.y = 5;
        System.out.println(p);
    }
}
